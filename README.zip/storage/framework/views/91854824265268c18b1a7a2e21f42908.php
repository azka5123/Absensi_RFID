<?php $__env->startSection('title', 'Siswa'); ?>

<?php $__env->startSection('container'); ?>
    <section class="content-wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="card mt-3">
                        <div class="card-header">
                            <div class="d-flex justify-content-between align-items-center">
                                
                                <h2 class="font-weight-bold">Data Siswa</h2>
                                <a href="<?php echo e(route('naik_kelas')); ?>"
                                    onclick="return confirm('Siswa akan dinaikan kelas selanjutnya')"
                                    class="btn btn-primary mb-3 run"><i class="bi bi-arrow-up-circle"></i> Naik Kelas</a>
                            </div>

                        </div>
                        <!-- /.card-header -->
                        <div class="card-body">
                            <a href="<?php echo e(route('create-student')); ?>" class="btn btn-primary mb-3"><i
                                    class="bi bi-plus-circle"></i> Tambah
                                Data</a>
                            <table id="example1" class="table table-bordered table-hover">
                                <thead>
                                    <tr>
                                        <th>Nomor Kartu</th>
                                        <th>UID</th>
                                        <th>Nama Siswa</th>
                                        <th>kelas</th>
                                        <th>Jurusan</th>
                                        <th>Nomor Wa Ortu</th>
                                        <th>NIS</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $student; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($data->nomor_kartu); ?></td>
                                            <td><?php echo e($data->uid); ?></td>
                                            <td><?php echo e($data->name); ?></td>
                                            <td><?php echo e($data->kelas); ?></td>
                                            <td><?php echo e($data->jurusan); ?></td>
                                            <td><?php echo e($data->hp_ortu); ?></td>
                                            <td><?php echo e($data->nis); ?></td>
                                            <td><a href="<?php echo e(route('edit-student', $data->id)); ?>"
                                                    class="btn btn-sm btn-success"><i class="bi bi-pencil-square"></i>
                                                    Edit</a>
                                                <a href="<?php echo e(route('delete-student', $data->id)); ?>"
                                                    onclick="return confirm('data akan dihapus')"
                                                    class="btn btn-sm btn-danger"><i class="bi bi-trash3"></i>
                                                    Delete</a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                </div>
                <!-- /.col -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Absensi_RFID\resources\views/student/student_show.blade.php ENDPATH**/ ?>