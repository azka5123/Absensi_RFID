<?php $__env->startSection('title', 'Absensi'); ?>

<?php $__env->startSection('container'); ?>
    <section class="content-wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">

                    <div class="card mt-3">
                        <div class="card-header">
                            <h2 class="font-weight-bold">Data Absensi</h2>
                        </div>
                        <!-- /.card-header -->
                        <div class="card-body">
                            <table id="example1" class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <th>Nama Siswa</th>
                                        <th>Kelas</th>
                                        <th>Jurusan</th>
                                        <th>Jam Masuk</th>
                                        <th>Jam Keluar</th>
                                        <th>Keterangan</th>
                                        <th>Izin</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $absen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($data->rStudent->name); ?></td>
                                            <td><?php echo e($data->rStudent->kelas); ?></td>
                                            <td><?php echo e($data->rStudent->jurusan); ?></td>
                                            <td>
                                                <?php if($data->jam_masuk != null): ?>
                                                    <?php echo e(Carbon\Carbon::parse($data->jam_masuk)->format('d-m-Y / H:i')); ?>

                                                <?php else: ?>
                                                    <?php echo e($data->jam_masuk); ?>

                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php if($data->jam_keluar != null): ?>
                                                    <?php echo e(Carbon\Carbon::parse($data->jam_keluar)->format('d-m-Y / H:i')); ?>

                                                <?php else: ?>
                                                    <?php echo e($data->jam_keluar); ?>

                                                <?php endif; ?>
                                            </td>
                                            <td><?php echo e($data->keterangan); ?></td>
                                            <td><?php echo e($data->izin); ?></td>
                                            <td><a href="<?php echo e(route('edit-absen', $data->id)); ?>"
                                                    class="btn btn-sm btn-success"><i class="bi bi-pencil-square"></i>
                                                    Edit</a>
                                            </td>
                                            
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                </div>
                <!-- /.col -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Absensi_RFID\resources\views/absen/absen_show.blade.php ENDPATH**/ ?>