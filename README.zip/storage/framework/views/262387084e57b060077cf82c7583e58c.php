
<?php $__env->startSection('title', 'Qr Code'); ?>

<?php $__env->startSection('container'); ?>
    <?php
        $image_qr = json_decode($response['body'], true);

    ?>
    <section class="content-wrapper">
        <div class="container">
            <br><br>
            <div class="embed-responsive embed-responsive-21by9">
                <iframe class="embed-responsive-item" src="<?php echo e($image_qr['image_url']); ?>" allowfullscreen></iframe>
            </div>
            <a href="<?php echo e(route('get-devices')); ?>" class="btn btn-primary btnback"><i class="bi bi-arrow-left-circle"></i>
                Kembali</a>
        </div>
    </section>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Absensi_RFID\resources\views/whatsapp/qr_code.blade.php ENDPATH**/ ?>