<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <link rel="shortcut icon" href="<?php echo e(asset('dist/dist/img/Tilkam.png')); ?>">
    <?php echo $__env->make('layouts.partials.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('layouts.partials.js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body class="hold-transition sidebar-mini layout-fixed layout-navbar-fixed layout-footer-fixed">
    
    <div class="wrapper">


        
        <div class="preloader flex-column justify-content-center align-items-center">
            <img class="animation__wobble" src="<?php echo e(asset('dist/dist/img/Tilkam.png')); ?>" alt="SMKN 1 TilKam"
                height="150" width="150">
        </div>
        

        
        <script>
            document.addEventListener("DOMContentLoaded", function() {
                <?php if(session()->get('error')): ?>
                    iziToast.error({
                        title: '',
                        position: 'topRight',
                        message: '<?php echo e(session()->get('error')); ?>',
                    });
                <?php endif; ?>

                <?php if(session()->get('success')): ?>
                    iziToast.success({
                        title: '',
                        position: 'topRight',
                        message: '<?php echo e(session()->get('success')); ?>',
                    });
                <?php endif; ?>
            });
        </script>
        <!-- End JavaScript section -->

        

        
        <?php echo $__env->make('layouts.partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        

        
        <?php echo $__env->make('layouts.partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        

        
        <?php echo $__env->yieldContent('container'); ?>
        

        
        <?php echo $__env->make('layouts.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
    </div>
    

    <?php echo $__env->make('layouts.partials.jsfooter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html>
<?php /**PATH D:\kuliah\laravel9\1_latihan\project\Absensi_RFID\resources\views/layouts/main.blade.php ENDPATH**/ ?>