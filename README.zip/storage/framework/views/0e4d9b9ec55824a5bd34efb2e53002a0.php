<!-- jQuery -->
<script src="<?php echo e(asset('dist/plugins/jquery/jquery.min.js')); ?>"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<script src="<?php echo e(asset('dist/dist/js/iziToast.js')); ?>"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/paho-mqtt/1.0.1/mqttws31.min.js" type="text/javascript"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/mqtt/2.18.8/mqtt.min.js"></script>


<script>
    $(document).ready(function(){
        $(".search").select2();
    });
</script>

<?php /**PATH C:\laragon\www\Absensi_RFID\resources\views/layouts/partials/js.blade.php ENDPATH**/ ?>