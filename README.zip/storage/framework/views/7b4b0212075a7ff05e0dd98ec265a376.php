
<?php $__env->startSection('title', 'Whatsapp'); ?>

<?php $__env->startSection('container'); ?>
    <?php
        $decodedData = json_decode($response['body'], true);
        $data = $decodedData['data'];
        $meta = $decodedData['meta'];
        // $image_qr = json_decode($qr['body'], true);
    ?>
    <section class="content-wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="card mt-3">
                        <div class="card-header">
                            <div class="d-flex justify-content-between align-items-center">
                                <h2 class="font-weight-bold">Whatsapp Status Device</h2>
                            </div>
                        </div>


                        <div class="card-body">
                            <a href="<?php echo e(route('qr-code')); ?>" class="btn btn-primary mb-3"><i
                                    class="bi bi-arrow-clockwise"></i>
                                Reconnect </a>
                            <table id="" class="table table-bordered table-hover">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td><?php echo e($data[0]['id']); ?></td>
                                        <td><?php echo e($data[0]['status']); ?></td>
                                        
                                    </tr>

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Absensi_RFID\resources\views/whatsapp/wa.blade.php ENDPATH**/ ?>