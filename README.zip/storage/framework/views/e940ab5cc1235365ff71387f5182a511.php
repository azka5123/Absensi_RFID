
<?php $__env->startSection('title', 'Edit User'); ?>
<?php $__env->startSection('container'); ?>
    <section class="content-wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">

                    <div class="card mt-3">
                        <div class="card-header">
                            <h2 class="font-weight-bold">Edit Data User</h2>
                        </div>
                        <!-- /.card-header -->
                        <div class="card-body">
                            <form action="<?php echo e(route('update-user', $edit->id)); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                    <div class="col col-6">
                                        <div class="form-group">
                                            <label>Nama</label>
                                            <input type="text" class="form-control form-control-sm" id="nama"
                                                name="nama" value="<?php echo e($edit->name); ?>">
                                        </div>
                                        <div class="form-group">
                                            <label>Email</label>
                                            <input type="email" class="form-control form-control-sm" id="email"
                                                name="email" value="<?php echo e($edit->email); ?>">
                                        </div>
                                        <div class="form-group">
                                            <label>Password</label>
                                            <input type="password" class="form-control form-control-sm" id="password"
                                                name="password">
                                        </div>
                                        <div class="form-group">
                                            <label>Role</label>
                                            <select class="custom-select form-control" id="role" name="role">
                                                <?php $__currentLoopData = ['Bimbingan Konseling', 'Operator']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($option); ?>"
                                                        <?php echo e($edit->role == $option ? 'selected' : ''); ?>> <?php echo e($option); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label>Nomor HP (62)</label>
                                            <input type="text" class="form-control form-control-sm" id="hp"
                                                name="hp" placeholder="Gunakan 62 untuk awalan: 62xxxxx">
                                        </div>
                                        <button type="submit" class="btn btn-primary btn-sm">Update data</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                </div>
                <!-- /.col -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Absensi_RFID\resources\views/user/user_edit.blade.php ENDPATH**/ ?>