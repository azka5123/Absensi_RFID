 <!-- Google Font: Source Sans Pro -->
 <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
 <!-- Font Awesome Icons -->
 <link rel="stylesheet" href="<?php echo e(asset('dist/plugins/fontawesome-free/css/all.min.css')); ?>">
 <!-- overlayScrollbars -->
 <link rel="stylesheet" href="<?php echo e(asset('dist/plugins/overlayScrollbars/css/OverlayScrollbars.min.css')); ?>">
 <!-- Theme style -->
 <link rel="stylesheet" href="<?php echo e(asset('dist/dist/css/adminlte.min.css')); ?>">

 
 <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">

 
 

 <!-- DataTables -->
 <link rel="stylesheet" href="<?php echo e(asset('dist/plugins/datatables-bs4/css/dataTables.bootstrap4.min.css')); ?>">
 <link rel="stylesheet" href="<?php echo e(asset('dist/plugins/datatables-responsive/css/responsive.bootstrap4.min.css')); ?>">
 <link rel="stylesheet" href="<?php echo e(asset('dist/plugins/datatables-buttons/css/buttons.bootstrap4.min.css')); ?>">

 
 <link rel="stylesheet" href="<?php echo e(asset('dist/dist/css/style.css')); ?>">
 <link rel="stylesheet" href="<?php echo e(asset('dist/dist/css/iziToast.css')); ?>">
<?php /**PATH D:\kuliah\laravel9\1_latihan\project\Absensi_RFID\resources\views/layouts/partials/style.blade.php ENDPATH**/ ?>