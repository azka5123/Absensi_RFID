<?php $__env->startSection('title', 'Edit Absensi'); ?>

<?php $__env->startSection('container'); ?>
    <section class="content-wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">

                    <div class="card mt-3">
                        <div class="card-header">
                            <h2 class="font-weight-bold">Tambah Data Absensi</h2>
                        </div>
                        <!-- /.card-header -->
                        <div class="card-body">
                            <form action="<?php echo e(route('update-absen', $edit->id)); ?>" method="post"
                                enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                    <div class="col col-6">
                                        <div class="form-group">
                                            <label>Nama Siswa</label>
                                            <input type="text" class="form-control form-control-sm" id="nama"
                                                name="nama" value="<?php echo e($edit->rStudent->name); ?>" readonly>
                                        </div>
                                        <div class="form-group">
                                            <label>NIS</label>
                                            <input type="text" class="form-control form-control-sm" id="nis"
                                                name="nis" value="<?php echo e($edit->rStudent->nis); ?>" readonly>
                                        </div>
                                        <div class="form-group">
                                            <label>Jurusan</label>
                                            <input type="text" class="form-control form-control-sm" id="jurusan"
                                                name="jurusan" value="<?php echo e($edit->rStudent->jurusan); ?>" readonly>
                                        </div>
                                        <div class="form-group">
                                            <label>Jam Masuk</label>
                                            <input type="datetime-local" class="form-control form-control-sm" id="masuk"
                                                name="masuk" value="<?php echo e($edit->jam_masuk); ?>">
                                        </div>
                                        <div class="form-group">
                                            <label>Jam Keluar</label>
                                            <input type="datetime-local" class="form-control form-control-sm" id="keluar"
                                                name="keluar" value="<?php echo e($edit->jam_keluar); ?>">
                                        </div>
                                        <div class="form-group">
                                            <label>Keterangan</label>
                                            <select class="custom-select form-control" id="keterangan" name="keterangan">
                                                <?php $__currentLoopData = ['Hadir', 'Terlambat', 'Alfa', 'Izin', 'Sakit']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($option); ?>"
                                                        <?php echo e($edit->keterangan == $option ? 'selected' : ''); ?>>
                                                        <?php echo e($option); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <button type="submit" class="btn btn-primary btn-sm">Edit</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                </div>
                <!-- /.col -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Absensi_RFID\resources\views/absen/absen_edit.blade.php ENDPATH**/ ?>