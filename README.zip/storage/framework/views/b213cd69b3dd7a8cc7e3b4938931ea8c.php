 <div class="table-responsive">
     <?php
         use Carbon\Carbon;
         setlocale(LC_TIME, 'id_ID.utf8');
         $now = Carbon::now();
         $bulan = $now->subMonths(1)->isoFormat('MMMM');
     ?>
     <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
         <tr>
             <td colspan="7" rowspan="2" align="center">Rekap Absensi bulan
                 <?php echo e($bulan); ?></td>
         </tr>
         <tr>
             <td></td>
         </tr>

         <tr>
             <th>Nama Siswa</th>
             <th>Kelas</th>
             <th>Jurusan</th>
             <th>Jam Masuk</th>
             <th>Jam Keluar</th>
             <th>Keterangan</th>
             <th>Izin</th>
         </tr>
         <tbody>
             <?php $__currentLoopData = $absen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <tr>
                     <td><?php echo e($data->rStudent->name); ?></td>
                     <td><?php echo e($data->rStudent->kelas); ?></td>
                     <td><?php echo e($data->rStudent->jurusan); ?></td>
                     <td>
                         <?php if($data->jam_masuk != null): ?>
                             <?php echo e(Carbon::parse($data->jam_masuk)->format('d-m-Y / H:i')); ?>

                         <?php else: ?>
                             <?php echo e($data->jam_masuk); ?>

                         <?php endif; ?>
                     </td>
                     <td>
                         <?php if($data->jam_keluar != null): ?>
                             <?php echo e(Carbon::parse($data->jam_keluar)->format('d-m-Y / H:i')); ?>

                         <?php else: ?>
                             <?php echo e($data->jam_keluar); ?>

                         <?php endif; ?>
                     </td>
                     <td><?php echo e($data->keterangan); ?></td>
                     <td><?php echo e($data->izin); ?></td>
                 </tr>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         </tbody>
     </table>
 </div>
<?php /**PATH D:\kuliah\laravel9\1_latihan\project\Absensi_RFID\resources\views/absen/absen_excel.blade.php ENDPATH**/ ?>