<?php $__env->startSection('title', 'Edit Student'); ?>

<?php $__env->startSection('container'); ?>
    <section class="content-wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">

                    <div class="card mt-3">
                        <div class="card-header">
                            <h2 class="font-weight-bold">Tambah Data Siswa</h2>
                        </div>
                        <!-- /.card-header -->
                        <div class="card-body">
                            <form action="<?php echo e(route('update-student', $edit->id)); ?>" method="post"
                                enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                    <div class="col col-6">
                                        <div class="form-group">
                                            <label>Nomor Kartu</label>
                                            <input type="text" class="form-control form-control-sm" id="nomor_kartu"
                                                name="nomor_kartu" value="<?php echo e($edit->nomor_kartu); ?>">
                                        </div>
                                        <div class="form-group">
                                            <label>UID</label>
                                            <input type="text" class="form-control form-control-sm" id="uid"
                                                name="uid" value="<?php echo e($edit->uid); ?>">
                                        </div>
                                        <div class="form-group">
                                            <label>Nama Siswa</label>
                                            <input type="text" class="form-control form-control-sm" id="nama"
                                                name="nama" value="<?php echo e($edit->name); ?>">
                                        </div>
                                        <div class="form-group">
                                            <label>NIS</label>
                                            <input type="text" class="form-control form-control-sm" id="nis"
                                                name="nis" value="<?php echo e($edit->nis); ?>">
                                        </div>
                                        <div class="form-group">
                                            <label>Kelas</label>
                                            <select class="custom-select form-control" id="kelas" name="kelas">
                                                <?php $__currentLoopData = ['X', 'XI', 'XII']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($option); ?>"
                                                        <?php echo e($edit->kelas == $option ? 'selected' : ''); ?>>
                                                        <?php echo e($option); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label>Jurusan</label>
                                            <select class="custom-select form-control" id="jurusan" name="jurusan">
                                                <?php $__currentLoopData = ['DPIB', 'TITL', 'TJKT', 'TKR']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($option); ?>"
                                                        <?php echo e($edit->jurusan == $option ? 'selected' : ''); ?>>
                                                        <?php echo e($option); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label>Nomor Wa Ortu (62)</label>
                                            <input type="text" class="form-control form-control-sm" id="hp_ortu"
                                                name="hp_ortu"
                                                placeholder="Gunakan 62 untuk awalan: 62xxxxx"value="<?php echo e($edit->hp_ortu); ?>">
                                        </div>
                                        <button type="submit" class="btn btn-primary btn-sm">Edit</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                </div>
                <!-- /.col -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\kuliah\laravel9\1_latihan\project\Absensi_RFID\resources\views/student/student_edit.blade.php ENDPATH**/ ?>