
<?php $__env->startSection('title', 'Sakit dan Izin'); ?>

<?php $__env->startSection('container'); ?>
    <section class="content-wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="card mt-3">
                        <div class="card-header">
                            <div class="d-flex justify-content-between align-items-center">
                                <h2 class="font-weight-bold">Data Siswa</h2>
                            </div>

                        </div>
                        <!-- /.card-header -->
                        <div class="card-body">
                            <table id="example1" class="table table-bordered table-hover">
                                <thead>
                                    <tr>
                                        <th>UID</th>
                                        <th>Nama Siswa</th>
                                        <th>kelas</th>
                                        <th>Jurusan</th>
                                        <th>Nomor Wa Ortu</th>
                                        <th>NIS</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $student; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($data->uid); ?></td>
                                            <td><?php echo e($data->name); ?></td>
                                            <td><?php echo e($data->kelas); ?></td>
                                            <td><?php echo e($data->jurusan); ?></td>
                                            <td><?php echo e($data->hp_ortu); ?></td>
                                            <td><?php echo e($data->nis); ?></td>
                                            <td>
                                                <a href="<?php echo e(route('sakit', $data->id)); ?>" class="btn btn-sm btn-info"><i
                                                        class="bi bi-file-earmark-medical"></i>
                                                    Sakit</a>
                                                <a href="<?php echo e(route('izin', $data->id)); ?>" class="btn btn-sm btn-primary"><i
                                                        class="bi bi-envelope-check"></i>
                                                    Izin</a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                </div>
                <!-- /.col -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Absensi_RFID\resources\views/absen/sakit/sakit_dan_izin_show.blade.php ENDPATH**/ ?>