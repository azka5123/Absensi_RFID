<nav class="main-header navbar navbar-expand navbar-dark">
    <!-- Left navbar links -->
    

    <!-- Right navbar links -->
    <ul class="navbar-nav ml-auto">
        <!-- Navbar Search -->
        

        <!-- Messages Dropdown Menu -->
        
        <!-- Notifications Dropdown Menu -->
        
        <li class="nav-item">
            <a class="nav-link" data-widget="fullscreen" href="#" role="button">
                <i class="fas fa-expand-arrows-alt"></i>
            </a>
        </li>
        
    </ul>
</nav>
<?php /**PATH C:\laragon\www\Absensi_RFID\resources\views/layouts/partials/navbar.blade.php ENDPATH**/ ?>